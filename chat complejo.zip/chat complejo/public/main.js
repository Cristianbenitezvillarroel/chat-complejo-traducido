$(function() {
    var FADE_TIME = 150; // ms
    var TYPING_TIMER_LENGTH = 400; // ms
    var COLORS = [
      '#e21400', '#91580f', '#f8a700', '#f78b00',
      '#58dc00', '#287b00', '#a8f07a', '#4ae8c4',
      '#3b88eb', '#3824aa', '#a700ff', '#d300e7'
    ];
  
    // Inicialización de variables
    var $window = $(window);
    var $usernameInput = $('.usernameInput'); // Input for username
    var $messages = $('.messages'); // Messages area
    var $inputMessage = $('.inputMessage'); // Input message input box
  
    var $loginPage = $('.login.page'); // The login page
    var $chatPage = $('.chat.page'); // The chatroom page
  
    // Preguntamos para establecer los datos del usuario
    var username;
    var connected = false;
    var typing = false;
    var lastTypingTime;
    var $currentInput = $usernameInput.focus();
  
    var socket = io();
  
    const addParticipantsMessage = (data) => {
      var message = '';
      if (data.numUsers === 1) {
        message += "Hay 1 participante";
      } else {
        message += "Hay " + data.numUsers + " participantes";
      }
      log(message);
    }
  
    // Establecer el nombre de usuario al cliente
    const setUsername = () => {
      username = cleanInput($usernameInput.val().trim());
  
      // Si el usuario es valido
      if (username) {
        $loginPage.fadeOut();
        $chatPage.show();
        $loginPage.off('click');
        $currentInput = $inputMessage.focus();
  
        // Indicar al servidor el nombre de usuario
        socket.emit('add user', username);
      }
    }
  
    // Mensajes de chat enviados
    const sendMessage = () => {
      var message = $inputMessage.val();
      // Impedir inserciones de marcadores en el mensaje
      message = cleanInput(message);
      // Si hay un mensaje distinto de vacio y una conexion de socket
      if (message && connected) {
        $inputMessage.val('');
        addChatMessage({
          username: username,
          message: message
        });
        // Indicar al servidor que ejecute el nuevo mensaje y enviarlo como parametro
        socket.emit('new message', message);
      }
    }
  
    // Registro de un mensaje
      const log = (message, options) => {
      var $el = $('<li>').addClass('log').text(message);
      addMessageElement($el, options);
    }
  
    // Añadir el mensaje visual del chat a una lista de mensajes
    const addChatMessage = (data, options) => {
      // No aparece el mensaje si hay alguien escribiendo
      var $typingMessages = getTypingMessages(data);
      options = options || {};
      if ($typingMessages.length !== 0) {
        options.fade = false;
        $typingMessages.remove();
      }
  
      var $usernameDiv = $('<span class="username"/>')
        .text(data.username)
        .css('color', getUsernameColor(data.username));
      var $messageBodyDiv = $('<span class="messageBody">')
        .text(data.message);
  
      var typingClass = data.typing ? 'typing' : '';
      var $messageDiv = $('<li class="message"/>')
        .data('username', data.username)
        .addClass(typingClass)
        .append($usernameDiv, $messageBodyDiv);
  
      addMessageElement($messageDiv, options);
    }
  
    // Añadir el mensaje al chat visual de que un usuario esta escribiendo
    const addChatTyping = (data) => {
      data.typing = true;
      data.message = 'is typing';
      addChatMessage(data);
    }
  
    // Eliminar el mensaje del chat visual de que un usuari esta escribiendo
    const removeChatTyping = (data) => {
      getTypingMessages(data).fadeOut(function () {
        $(this).remove();
      });
    }
  
    // Añade un elemento mensaje a la lista de mensajes y lo envia abajo del todo
    // El elemento a añadir como mensaje
    // options.fade - Si el elemento deberia aparecer (por defecto verdadero)
    // options.prepend - Si el elemento deberia anteponerse
    // El resto de mensajes (por defecto falso)
    const addMessageElement = (el, options) => {
      var $el = $(el);
  
      // Configurar opciones predeterminadas
      if (!options) {
        options = {};
      }
      if (typeof options.fade === 'undefined') {
        options.fade = true;
      }
      if (typeof options.prepend === 'undefined') {
        options.prepend = false;
      }
  
      // Aplicar opciones
      if (options.fade) {
        $el.hide().fadeIn(FADE_TIME);
      }
      if (options.prepend) {
        $messages.prepend($el);
      } else {
        $messages.append($el);
      }
      $messages[0].scrollTop = $messages[0].scrollHeight;
    }
  
    // Evita que la entrada tenga insercion de marcadores
    const cleanInput = (input) => {
      return $('<div/>').text(input).html();
    }
  
    // Actualiza el evento de escritura
    const updateTyping = () => {
      if (connected) {
        if (!typing) {
          typing = true;
          socket.emit('typing');
        }
        lastTypingTime = (new Date()).getTime();
  
        setTimeout(() => {
          var typingTimer = (new Date()).getTime();
          var timeDiff = typingTimer - lastTypingTime;
          if (timeDiff >= TYPING_TIMER_LENGTH && typing) {
            socket.emit('stop typing');
            typing = false;
          }
        }, TYPING_TIMER_LENGTH);
      }
    }
  
    // Obtiene los mensajes de que el usuario está escribiendo
    const getTypingMessages = (data) => {
      return $('.typing.message').filter(function (i) {
        return $(this).data('username') === data.username;
      });
    }
  
    // Obtine el color de un nombre de usuario a traves de nuestr funcion hash
    const getUsernameColor = (username) => {
      // Calcula el codigo hash
      var hash = 7;
      for (var i = 0; i < username.length; i++) {
         hash = username.charCodeAt(i) + (hash << 5) - hash;
      }
      // Calcula el color
      var index = Math.abs(hash % COLORS.length);
      return COLORS[index];
    }
  
    // Eventos de teclado
    $window.keydown(event => {
      // Enfocar automaticamente la entrada actual cuando se teclea una tecla
      if (!(event.ctrlKey || event.metaKey || event.altKey)) {
        $currentInput.focus();
      }
      // Cuando el cliente pulsa intro en su teclado
      if (event.which === 13) {
        if (username) {
          sendMessage();
          socket.emit('stop typing');
          typing = false;
        } else {
          setUsername();
        }
      }
    });
  
    $inputMessage.on('input', () => {
      updateTyping();
    });
  
    // Eventos de click
  
    // Enfoque de entrada al hacer clic en cualquier lugar en la página de inicio de sesión
    $loginPage.click(() => {
      $currentInput.focus();
    });
  
    // Enfoque de entrada al hacer clic en el borde de entrada del mensaje
    $inputMessage.click(() => {
      $inputMessage.focus();
    });
  
    // Eventos socket
  
    // Cuando el servidor emita 'login', registra el mensaje de inicio de sesión
    socket.on('login', (data) => {
      connected = true;
      // Muestra el mensaje de bienvenida
      var message = "Bienvenido a Socket.IO Chat – ";
      log(message, {
        prepend: true
      });
      addParticipantsMessage(data);
    });
  
    // Siempre que el servidor emita 'mensaje nuevo', actualiza el cuerpo del chat
    socket.on('new message', (data) => {
      addChatMessage(data);
    });
  
    // Siempre que el servidor emita 'user joined', inicia sesión en el cuerpo del chat
    socket.on('user joined', (data) => {
      log(data.username + ' joined');
      addParticipantsMessage(data);
    });
  
  // Siempre que el servidor emita 'user left', se registra en el cuerpo del chat
    socket.on('user left', (data) => {
      log(data.username + ' left');
      addParticipantsMessage(data);
      removeChatTyping(data);
    });
  
    // Cuando el servidor emita 'typing', muestra el mensaje escribiendo
    socket.on('typing', (data) => {
      addChatTyping(data);
    });
  
    // Siempre que el servidor emita 'stop typing', elimina el mensaje de escritura
    socket.on('stop typing', (data) => {
      removeChatTyping(data);
    });
  
    socket.on('disconnect', () => {
      log('has sido desconectado');
    });
  
    socket.on('reconnect', () => {
      log('te has reconectado');
      if (username) {
        socket.emit('add user', username);
      }
    });
  
    socket.on('reconnect_error', () => {
      log('reconexión fallida');
    });
  
  });